<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminPageController extends Controller{

    public function dashboard(){
        return view('backend.pages.dashboard', ['title' => 'Dashboard']);
    }

}