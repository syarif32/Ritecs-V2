<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Category;
use App\Models\Writer;
use App\Models\User; // <-- tambahkan ini


class PublishedBooksController extends Controller
{
    // List semua buku
    public function bookData()
    {
        $books = Book::with(['categories', 'writers'])->get();
        return view('backend.pages.published-books.books-data', compact('books'), 
        ['title' => 'Book Data']);
    }

    // Form create
    public function bookCreate()
    {
        $categories = Category::all();
        $writers    = Writer::all();
        $users      = User::select('user_id','first_name','last_name','email')->get(); // ← ambil user

        return view(
            'backend.pages.published-books.add-books',
            compact('categories', 'writers', 'users'), // ← kirim ke view
            ['title' => 'Book Data']
        );
    }

    // Store buku baru
    public function bookStore(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'coverImage' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'category' => 'required|array|min:1',
            'writter' => 'required|array|min:1',
            'isbn' => 'nullable|unique:books,isbn',
            'ebook_path' => 'nullable|url',
        ]);

        $book = new Book();
        $book->title = $request->title;
        $book->synopsis = $request->Synopsis ?? null;
        $book->publisher = $request->publisher ?? null;
        $book->pages = $request->pages ?? null;
        $book->width = $request->width ?? null;
        $book->length = $request->length ?? null;
        $book->thickness = $request->thickness ?? null;
        $book->publish_date = $request->publish_date ?? null;
        $book->isbn = $request->isbn ?? null;
        $book->ebook_path = $request->ebook_path ?? null;
        $book->print_price = $request->print_price ?? null;
        $book->ebook_price = $request->ebook_price ?? null;

        // Upload cover
        // UNTUK RUN DI LOCAL JALANKAN INI
            // if ($request->hasFile('coverImage')) {
            //     $filename = time() . '_' . $request->file('coverImage')->getClientOriginalName();
            //     $request->file('coverImage')->move(public_path('assets/published/books'), $filename);
            //     $book->cover_path = 'assets/published/books/' . $filename;
            // }

        // UNTUK RUN DI SERVER HOSTING JALANKAN INI & NONAKTIFKAN FUNGSI DI ATAS
        $destination = base_path('assets/published/books'); 
        if (!file_exists($destination)) {
            mkdir($destination, 0755, true);
        }
        // Upload cover
        if ($request->hasFile('coverImage')) {
            $filename = time() . '_' . $request->file('coverImage')->getClientOriginalName();
            $request->file('coverImage')->move($destination, $filename);
            $book->cover_path = 'assets/published/books/' . $filename;
        }

        $book->save();

        // Sync relasi
        $book->categories()->sync($request->category);
        $book->writers()->sync($request->writter);

        return redirect()->route('admin.published-books')->with('success', 'Book added successfully.');
    }

    // Edit form
    public function bookEdit($id)
    {
        $book       = Book::with(['categories', 'writers'])->findOrFail($id);
        $categories = Category::all();
        $writers    = Writer::all();
        $users      = User::select('user_id','first_name','last_name','email')->get(); // ← kirim juga

        return view('backend.pages.published-books.edit-books',
            compact('book', 'categories', 'writers', 'users'),
            ['title' => 'Book Data']
        );
    }

    // Update
    public function bookUpdate(Request $request, $id)
    {
        $book = Book::findOrFail($id);

        $request->validate([
            'title' => 'required|string|max:255',
            'coverImage' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'category' => 'required|array|min:1',
            'writter' => 'required|array|min:1',
            'isbn' => 'nullable|unique:books,isbn,' . $book->book_id . ',book_id',
            'ebook_path' => 'nullable|url',
        ]);

        $book->title = $request->title;
        $book->synopsis = $request->Synopsis ?? null;
        $book->publisher = $request->publisher ?? null;
        $book->pages = $request->pages ?? null;
        $book->width = $request->width ?? null;
        $book->length = $request->length ?? null;
        $book->thickness = $request->thickness ?? null;
        $book->publish_date = $request->publish_date ?? null;
        $book->isbn = $request->isbn ?? null;
        $book->ebook_path = $request->ebook_path ?? null;
        $book->print_price = $request->print_price ?? null;
        $book->ebook_price = $request->ebook_price ?? null;

        if ($request->hasFile('coverImage')) {
            $defaultCover = 'assets/published/books/book_default.png';

            // Hapus cover lama jika bukan default
            // UNTUK RUN DI LOCAL JALANKAN INI
                // if ($book->cover_path && $book->cover_path !== $defaultCover) {
                //     $oldPath = public_path($book->cover_path);
                //     if (file_exists($oldPath)) {
                //         unlink($oldPath);
                //     }
                // }
            
            // UNTUK RUN DI SERVER HOSTING JALANKAN INI & NONAKTIFKAN FUNGSI DI ATAS
            if ($book->cover_path && $book->cover_path !== $defaultCover) {
                $oldPath = base_path($book->cover_path);
                if (file_exists($oldPath)) {
                    unlink($oldPath);
                }
            }

            // Upload cover baru
            // UNTUK RUN DI LOCAL JALANKAN INI
                // $filename = time() . '_' . $request->file('coverImage')->getClientOriginalName();
                // $request->file('coverImage')->move(public_path('assets/published/books'), $filename);
                // $book->cover_path = 'assets/published/books/' . $filename;


            // UNTUK RUN DI SERVER HOSTING JALANKAN INI & NONAKTIFKAN FUNGSI DI ATAS
            $destination = base_path('assets/published/books'); 
            if (!file_exists($destination)) {
                mkdir($destination, 0755, true);
            }

            // Upload cover baru
            $filename = time() . '_' . $request->file('coverImage')->getClientOriginalName();
            $request->file('coverImage')->move($destination, $filename);
            $book->cover_path = 'assets/published/books/' . $filename;
        }


        $book->save();

        // Sync relasi
        $book->categories()->sync($request->category);
        $book->writers()->sync($request->writter);

        return redirect()->route('admin.published-books')->with('success', 'Book updated successfully.');
    }

    // Delete
    public function bookDelete($id)
    {
        $book = Book::findOrFail($id);

        // Path default (hardcode agar aman)
        $defaultCover = 'assets/published/books/book_default.png';

        // Hapus file cover jika bukan default
        // Gunakan ini untuk RUN di local
            // if ($book->cover_path && $book->cover_path !== $defaultCover) {
            //     $oldPath = public_path($book->cover_path);
            //     if (file_exists($oldPath)) {
            //         unlink($oldPath);
            //     }
            // }

        // Gunakan ini untuk RUN di Server Hosting 
        if ($book->cover_path && $book->cover_path !== $defaultCover) {
            $oldPath = base_path($book->cover_path);
            if (file_exists($oldPath)) {
                unlink($oldPath);
            }
        }

        $book->categories()->detach();
        $book->writers()->detach();
        $book->delete();

        return redirect()->route('admin.published-books')->with('success', 'Book deleted successfully.');
    }



}
