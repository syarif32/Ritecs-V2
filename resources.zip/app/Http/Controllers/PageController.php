<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Journal;
use App\Models\Keyword;
use App\Models\Book;

class PageController extends Controller
{
    public function home()
    {
        $journals = Journal::with('keywords')->latest()->take(3)->get();
        return view('pages.home', [
            'title' => 'Home',
            'journals' => $journals
        ]);
    }

    public function about()
    {
        return view('pages.about', ['title' => 'About']);
    }

    // public function contact()
    // {
    //     return view('pages.contact', ['title' => 'Contact']);
    // }

    public function buku()
    {
        $books = Book::with(['writers', 'categories'])->latest()->get();

        return view('pages.buku', [
            'title' => 'Buku',
            'books' => $books
        ]);
    }

    public function detailBuku($id)
    {
        $book = Book::with(['writers', 'categories'])->findOrFail($id);

        return view('pages.detail-buku', [
            'title' => $book->title,
            'book' => $book
        ]);
    }
    public function service()
    {
        return view('pages.service', ['title' => 'Service']);
    }


    public function petunjukPenulis()
    {
        return view('pages.petunjuk-penulis', ['title' => 'Petunjuk Penulis']);
    }
    public function ircsJournal()
    {
        return view('pages.ircs-journal', ['title' => 'Layanan Jurnal']);
    }
    public function membership()
    {
        return view('pages.membership', ['title' => 'Membership']);
    }


    public function journal()
    {

        $keywords = Keyword::orderBy('name')->get();
        $query = Journal::query()->with('keywords');
        if (request()->has('keyword') && request('keyword') != '') {
            $query->whereHas('keywords', function ($q) {
                $q->where('name', request('keyword'));
            });
        }
        if (request()->has('search') && request('search') != '') {
            $searchTerm = request('search');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', '%' . $searchTerm . '%')
                    ->orWhereHas('keywords', function ($keywordQuery) use ($searchTerm) {
                        $keywordQuery->where('name', 'like', '%' . $searchTerm . '%');
                    });
            });
        }
        $sortBy = request('sort', 'newest');
        switch ($sortBy) {
            case 'oldest':
                $query->oldest();
                break;
            case 'title_asc':
                $query->orderBy('title', 'asc');
                break;
            default:
                $query->latest();
                break;
        }
        $journals = $query->paginate(9)->appends(request()->query());

        return view('pages.journal', [
            'title' => 'Jurnal',
            'journals' => $journals,
            'keywords' => $keywords
        ]);
    }

    public function detailjurnal()
    {
        return view('pages.detail-jurnal', ['title' => 'Detail Jurnal']);
    }



}
