<?php

// GUNAKAN HELPER UNTUK UBAH ROOTS FOLDER PUBLIC
if (!function_exists('public_path')) {
    function public_path($path = '')
    {
        return base_path('sites' . ($path ? DIRECTORY_SEPARATOR.$path : $path));
    }
}
