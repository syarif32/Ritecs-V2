<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ChatbotController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminPageController;
use App\Http\Controllers\PublishedJournalsController;
use App\Http\Controllers\PublishedBooksController;
use App\Http\Controllers\KeywordController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\WriterController;

use App\Http\Controllers\Auth\AuthController;


use App\Http\Controllers\Admin\UserController;
Route::get('/login', function () {
    return redirect()->route('home')->with('login_required', 'Anda harus login untuk mengakses halaman ini!');
})->name('login');

// Rute Autentikasi
Route::post('/register', [AuthController::class, 'register'])->name('register');
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');




Route::middleware(['auth', 'role:Admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminPageController::class, 'dashboard'])->name('dashboard');

    // Published Journals
    Route::get('/published-journals', [PublishedJournalsController::class, 'journalData'])->name('published-journals');

    // View, Update & Delete Journal - (note: edit memakai {id} dan update POST ke {id})
    Route::get('/edit-journal/{id}', [PublishedJournalsController::class, 'journalEdit'])->name('edit-journals');
    Route::post('/update-journal/{id}', [PublishedJournalsController::class, 'journalUpdate'])->name('update-journals');
    Route::get('/delete-journal/{id}', [PublishedJournalsController::class, 'journalDelete'])->name('delete-journals');
    Route::get('/add-journal', [PublishedJournalsController::class, 'journalCreate'])->name('create-journals');
    Route::post('/store-journal', [PublishedJournalsController::class, 'journalStore'])->name('store-journals');
    Route::get('/users', [UserController::class, 'index'])->name('users.index');

    Route::get('/published-books', [PublishedBooksController::class, 'bookData'])->name('published-books');
    Route::get('/add-book', [PublishedBooksController::class, 'bookCreate'])->name('create-books');
    Route::post('/store-book', [PublishedBooksController::class, 'bookStore'])->name('store-books');
    Route::get('/edit-book/{id}', [PublishedBooksController::class, 'bookEdit'])->name('edit-books');
    Route::post('/update-book/{id}', [PublishedBooksController::class, 'bookUpdate'])->name('update-books');
    Route::get('/delete-book/{id}', [PublishedBooksController::class, 'bookDelete'])->name('delete-books');
    
    // Keywords Journal
    Route::get('/keywords', [KeywordController::class, 'index'])->name('keywords');
    Route::get('/keywords/create', [KeywordController::class, 'create'])->name('keywords.create');
    Route::post('/keywords/store', [KeywordController::class, 'store'])->name('keywords.store');
    Route::get('/keywords/edit/{id}', [KeywordController::class, 'edit'])->name('keywords.edit');
    Route::post('/keywords/update/{id}', [KeywordController::class, 'update'])->name('keywords.update');
    Route::get('/keywords/delete/{id}', [KeywordController::class, 'destroy'])->name('keywords.delete');

    // Categories Book
    Route::get('/categories', [CategoryController::class, 'index'])->name('categories');
    Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories.create');
    Route::post('/categories/store', [CategoryController::class, 'store'])->name('categories.store');
    Route::get('/categories/edit/{id}', [CategoryController::class, 'edit'])->name('categories.edit');
    Route::post('/categories/update/{id}', [CategoryController::class, 'update'])->name('categories.update');
    Route::get('/categories/delete/{id}', [CategoryController::class, 'destroy'])->name('categories.delete');

    // Writers Book
    Route::get('/writers', [WriterController::class, 'index'])->name('writers');
    Route::get('/writers/create', [WriterController::class, 'create'])->name('writers.create');
    Route::post('/writers/store', [WriterController::class, 'store'])->name('writers.store');
    Route::get('/writers/edit/{id}', [WriterController::class, 'edit'])->name('writers.edit');
    Route::put('/writers/update/{id}', [WriterController::class, 'update'])->name('writers.update');
    Route::get('/writers/delete/{id}', [WriterController::class, 'destroy'])->name('writers.delete');
    Route::post('/admin/writers/ajax-store', [App\Http\Controllers\WriterController::class, 'ajaxStore'])->name('writers.ajax-store');


});



Route::middleware('auth')->prefix('profile')->name('profile.')->group(function () {
    Route::get('/dashboard', [ProfileController::class, 'dashboard'])->name('dashboard');
    Route::get('/member', [ProfileController::class, 'member'])->name('member');
    Route::get('/settings', [ProfileController::class, 'settings'])->name('settings');
});

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/about', [PageController::class, 'about'])->name('about');
Route::get('/contact', [PageController::class, 'contact'])->name('contact');
Route::get('/buku', [PageController::class, 'buku'])->name('buku');
Route::get('/buku/{id}', [PageController::class, 'detailBuku'])->name('buku.detail');
Route::get('/service', [PageController::class, 'service'])->name('service');
Route::get('/detail-buku', [PageController::class, 'detailBuku'])->name('detail-buku');
Route::get('/petunjuk-penulis', [PageController::class, 'petunjukPenulis'])->name('petunjuk-penulis');
Route::get('/layanan-journal', [PageController::class, 'ircsJournal'])->name('layanan-journal');
Route::get('/ircs-journal', [PageController::class, 'ircsJournal'])->name('ircs-journal');
Route::get('/membership', [PageController::class, 'membership'])->name('membership');

Route::get('/journal', [PageController::class, 'journal'])->name('journal');
Route::get('/detail-jurnal', [PageController::class, 'detailjurnal'])->name('detail-jurnal');

// Route contact
Route::get('/contact', [ContactController::class, 'contact'])->name('contact');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');
















// // chatbot routes
// Route::get('/chatbot', [ChatbotController::class, 'showChat'])->name('chatbot.show');
// Route::post('/chatbot/send', [ChatbotController::class, 'sendMessage'])->name('chatbot.send');
// use Gemini\Laravel\Facades\Gemini; // <-- Pastikan ini ada di atas file

// Route::get('/test-gemini', function () {
//     try {
//         // Kita hanya perlu memanggil metode sederhana untuk tes,
//         // tidak perlu mengirim chat. Ini untuk membuktikan class-nya bisa dimuat.
//         $result = Gemini::models()->list(); 

//         return '✅ SUKSES: Paket Gemini berhasil dimuat oleh Laravel!';

//     } catch (\Throwable $e) {
//         // Jika terjadi error, kita akan menampilkannya langsung di browser.
//         // Ini akan memberikan pesan error yang lebih jelas.
//         return '❌ GAGAL: Terjadi error. Pesan: <pre>' . $e->getMessage() . '</pre>';
//     }
// });