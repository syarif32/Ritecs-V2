@extends('layouts.main')

@section('content')

    <!-- Carousel Start -->
    <div class="header-carousel owl-carousel">
        <div class="header-carousel-item bg-primary">
            <div class="carousel-caption">
                <div class="container">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-7 animated fadeInLeft">
                            <div class="text-sm-center text-md-start">
                                <h4 class="text-white text-uppercase fw-bold mb-4">Perkumpulan Riset dan Inovasi pada
                                    Teknologi Computer Science
                                    (Ritecs)</h4>
                                <h2 class="display-1 text-white mb-4">SATU LANGKAH LAGI MENCAPAINYA</h1>
                                    <p class="mb-5 fs-5">
                                        Kami dampingi Anda untuk menerbitkan buku berkualitas. Anda hanya cukup menulis
                                        naskah yang baik, selebihnya kami yang mengantarkan karya Anda sampai pada publikasi
                                        profesional ber-ISBN untuk masyarakat.
                                    </p>
                                    <div class="d-flex justify-content-center justify-content-md-start flex-shrink-0 mb-4">
                                        <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="#"><i
                                                class="fas fa-play-circle me-2"></i> Watch Video</a>
                                        <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="#feature">Learn More</a>
                                    </div>
                            </div>
                        </div>
                        <div class="col-lg-5 animated fadeInRight">
                            <div class="calrousel-img" style="object-fit: cover;">
                                <img src="assets/img/carousel-2.png" class="img-fluid w-100" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-carousel-item bg-primary">
            <div class="carousel-caption">
                <div class="container">
                    <div class="row gy-4 gy-lg-0 gx-0 gx-lg-5 align-items-center">
                        <div class="col-lg-5 animated fadeInLeft">
                            <div class="calrousel-img">
                                <img src="assets/img/carousel-2.png" class="img-fluid w-100" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7 animated fadeInRight">
                            <div class="text-sm-center text-md-end">
                                <h4 class="text-white text-uppercase fw-bold mb-4">Perkumpulan Riset dan Inovasi pada
                                    Teknologi Computer Science
                                    (Ritecs)</h4>
                                <h1 class="display-1 text-white mb-4">SATU LANGKAH LAGI MENCAPAINYA</h1>
                                <p class="mb-5 fs-5">Kami dampingi Anda untuk menerbitkan buku berkualitas. Anda hanya cukup
                                    menulis naskah yang baik, selebihnya kami yang mengantarkan karya Anda sampai pada
                                    publikasi profesional ber-ISBN untuk masyarakat.
                                </p>
                                <div class="d-flex justify-content-center justify-content-md-end flex-shrink-0 mb-4">
                                    <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="#"><i
                                            class="fas fa-play-circle me-2"></i> Watch Video</a>
                                    <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="#feature">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->

    <!-- Feature Start -->
    <div class="container-fluid feature bg-light py-5">
        <div class="container py-5" id="feature">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                <h4 class="text-primary">Layanan Kami</h4>
                <h1 class="display-4 mb-4">Apa yang Kami Tawarkan</h1>
                <p class="mb-0">
                    RITECS menyediakan berbagai layanan penerbitan buku dan jurnal, mulai dari penyuntingan naskah,
                    tata letak halaman, desain grafis, hingga penerbitan ber-ISBN. Kami juga menawarkan layanan
                    membership untuk mendukung penulis dan akademisi dalam mengembangkan karya mereka.
                </p>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="feature-item h-100 p-4 pt-0">
                        <div class="feature-icon p-4 mb-4">
                            <i class="fas fa-book-open fa-3x"></i>
                        </div>
                        <h4 class="mb-4">Penerbitan Buku</h4>
                        <p class="mb-4">Kami mendampingi Anda dalam proses penerbitan buku ber-ISBN dengan kualitas
                            profesional. Mulai dari penyuntingan, tata letak, desain grafis, hingga publikasi, yang
                            manjangkau pasar global.
                        </p>
                        <a class="btn btn-primary rounded-pill py-2 px-4 {{ ($title ?? '') === 'Petunjuk Penulis' ? 'active' : '' }}"
                            href="{{ route('petunjuk-penulis') }}#petunjuk-penulis">Learn More</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="feature-item h-100 p-4 pt-0">
                        <div class="feature-icon p-4 mb-4">
                            <i class="fas fa-newspaper fa-3x"></i>
                        </div>
                        <h4 class="mb-4">Penerbitan Jurnal</h4>
                        <p class="mb-4">Kami menyediakan layanan penerbitan jurnal ilmiah yang kredibel, mulai dari
                            pendampingan proses editorial, pengelolaan peer-review, hingga distribusi digital yang
                            menjangkau pembaca global.
                        </p>
                        <a class="btn btn-primary rounded-pill py-2 px-4 {{ in_array($title ?? '', ['Jurnal', 'Detail Jurnal']) ? 'active' : '' }}"
                            href="{{ route('ircs-journal') }}#layanan-jurnal">Learn More</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.6s">
                    <div class="feature-item h-100 p-4 pt-0">
                        <div class="feature-icon p-4 mb-4">
                            <i class="fas fa-users fa-3x"></i>
                        </div>
                        <h4 class="mb-4">Membership</h4>
                        <p class="mb-4">Bergabunglah dalam membership RITECS dan nikmati berbagai manfaat, mulai dari akses
                            informasi terkini, dukungan publikasi, hingga peluang kolaborasi untuk pengembangan karya
                            akademik dan profesional Anda.
                        </p>
                        <a class="btn btn-primary rounded-pill py-2 px-4 {{ ($title ?? '') === 'Membership' ? 'active' : '' }}"
                            href="{{ route('membership') }}#membership">Learn More</a>
                    </div>
                </div>
                <!-- <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.8s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-th-large fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Tata Letak Halaman</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="1s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-drafting-compass fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Design Grafis Ilustrasi</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="1.2s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-language fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Translate&Proofreading</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div> -->
            </div>

            <!-- <div class="row g-4 justify-content-center">
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-book-open fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Penerbitan Buku</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.4s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-newspaper fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Penerbitan Jurnal</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.6s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-edit fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Penyuntingan Naskah</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.8s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-th-large fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Tata Letak Halaman</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="1s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-drafting-compass fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Design Grafis Ilustrasi</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="1.2s">
                            <div class="feature-item h-100 p-4 pt-0">
                                <div class="feature-icon p-4 mb-4">
                                    <i class="fas fa-language fa-3x"></i>
                                </div>
                                <h4 class="mb-4">Translate & Proofreading</h4>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea hic laborum odit
                                    pariatur...
                                </p>
                                <a class="btn btn-primary rounded-pill py-2 px-4" href="#">Learn More</a>
                            </div>
                        </div>
                    </div> -->

        </div>
    </div>
    <!-- Feature End -->

    <!-- About Start -->
    <div class="container-fluid bg-light about pb-5 pt-5">
        <div class="container pb-5">
            <div class="row g-5">
                <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="about-item-content bg-white rounded p-5 h-100">
                        <h4 class="text-primary">Tentang Kami</h4>
                        <h1 class="display-4 mb-4">VISI & MISI</h1>
                        <H3>Visi
                        </H3>
                        <p>Menyediakan layanan terpercaya dan inklusif dalam mendukung dan berkontribusi nyata bagi
                            pengembangan ilmu pengetahuan, budaya baca, dan daya imajinasi bangsa.</p>
                        <H3>Misi
                        </H3>
                        <p class="text-dark"><i class="fa fa-check text-primary me-3"></i>Menerbitkan karya ilmiah dan
                            kreatif dari berbagai latar belakang.</p>
                        <p class="text-dark"><i class="fa fa-check text-primary me-3"></i>Mendukung literasi dan budaya baca
                            melalui publikasi ilmiah dan non-ilmiah.</p>
                        <p class="text-dark mb-4"><i class="fa fa-check text-primary me-3"></i>Menjaga kualitas dan etika
                            dalam proses penerbitan.</p>
                        <a class="btn btn-primary rounded-pill py-2 px-5" href="#blog">Informasi Lainnya</a>
                        
                    </div>
                </div>
                <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.2s">
                    <div class="bg-white rounded p-5 h-100">
                        <div class="row g-4 justify-content-center">
                            <div class="col-12">
                                <div class="rounded bg-light">
                                    <img src="assets/img/tim.png" class="img-fluid rounded w-100" alt="">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="counter-item bg-light rounded p-3 h-100">
                                    <div class="counter-counting">
                                        <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">10</span>
                                        <span class="h1 fw-bold text-primary">+</span>
                                    </div>
                                    <h4 class="mb-0 text-dark">Tenaga Ahli</h4>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="counter-item bg-light rounded p-3 h-100">
                                    <div class="counter-counting">
                                        <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">5</span>
                                        <span class="h1 fw-bold text-primary">+</span>
                                    </div>
                                    <h4 class="mb-0 text-dark">Layanan</h4>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="counter-item bg-light rounded p-3 h-100">
                                    <div class="counter-counting">
                                        <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">12</span>
                                        <span class="h1 fw-bold text-primary">+</span>
                                    </div>
                                    <h4 class="mb-0 text-dark">Skilled Agents</h4>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="counter-item bg-light rounded p-3 h-100">
                                    <div class="counter-counting">
                                        <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">15</span>
                                        <span class="h1 fw-bold text-primary">+</span>
                                    </div>
                                    <h4 class="mb-0 text-dark">Team Members</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Blog Start -->
    <div class="container-fluid blog py-5" id="blog">
        <div class="container py-5 text-center">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                <!-- <h4 class="text-primary">Blog</h4> -->
                <h1 class="display-4 mb-4">News And Updates</h1>
                <!-- <h3 class="display-4 mb-4">Book & Journal</h1> -->
                <p class="mb-0">Dapatkan informasi terbaru seputar penerbitan buku dan jurnal, rilis terbaru, serta
                    aktivitas RITECS.</p>
                </p>
            </div>
           <div class="row g-4 justify-content-start text-start">
                        @forelse ($journals as $journal)
                        <div class="col col-12 col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.6s">
                            <div class="blog-item rounded">
                                <div class="blog-img rounded-top">
                                    <img src="{{ asset($journal->cover_path) }}" class="img-fluid rounded-top w-100" alt="{{ $journal->title }}">
                                </div>
                                <div class="blog-content h-100 rounded p-3 d-grid align-content-between">
                                    <div class="card-body p-0 m-0">
                                        <a href="{{ $journal->url_path }}" target="_blank" class="h6 d-inline-block mb-2">{{ Str::limit($journal->title, 55) }}</a>
                                        @if ($journal->keywords->isNotEmpty())
                                        <div class="kata-kunci my-1">
                                            <p class="h6 small mb-0 ">Kategori : </p>
                                            @foreach ($journal->keywords as $keyword)
                                                <span class="keywords-badge py-0 small my-1 ms-0 me-1">{{ $keyword->name }}</span>
                                            @endforeach
                                        </div>
                                        @endif
                                    </div>
                                    <a href="{{ $journal->url_path }}" target="_blank" class="p-0 text-dark small position-relative bottom-0">Detail jurnal<i class="fa fa-arrow-right ms-2 small"></i></a>
                                </div>
                            </div>
                        </div>
                        @empty
                        <div class="col-12 text-center">
                            <p class="text-muted fs-5">Jurnal tidak ditemukan.</p>
                        </div>
                        @endforelse
                    </div>

            <a href="" class="btn btn-primary rounded-pill py-2 px-5 mt-4 m-auto text-center wow fadeInUp"
                data-wow-delay="0.8s">Berita Lainnya</a>
        </div>
    </div>
    <!-- Blog End -->
    <!-- FAQs Start -->
    <div class="container-fluid faq-section bg-light py-5">
        <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="h-100">
                        <div class="mb-5">
                            <h4 class="text-primary">Some Important FAQ's</h4>
                            <h1 class="display-5 mb-0">Pertanyaan umum tentang layanan dan penerbitan di RITECS.</h1>
                        </div>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button border-0" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Q: Apa itu RITECS??
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show active"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body rounded">
                                        A: RITECS adalah lembaga penerbitan profesional yang menyediakan layanan publikasi
                                        buku, jurnal, dan pendampingan akademik.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Q: Apakah saya bisa menerbitkan buku sendiri di RITECS?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        A: Ya, Anda bisa menerbitkan buku sendiri di RITECS. Kami menyediakan layanan
                                        penerbitan yang lengkap, mulai dari penyuntingan hingga penerbitan ber-ISBN.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        Q: Berapa biaya untuk menerbitkan buku di RITECS?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        A: Biaya publikasi buku mulai dari Rp1.500.000, termasuk penyuntingan, tata letak,
                                        desain grafis, dan pengurusan ISBN.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.4s">
                    <img src="assets/img/carousel-2.png" class="img-fluid w-100" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- FAQs End -->

    <!-- Team Start -->
    <!-- <div class="container-fluid team pb-5 pt-5">
        <div class="container pb-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                <h4 class="text-primary">Our Team</h4>
                <h1 class="display-4 mb-4">Meet Our Expert Team Members</h1>
                <p class="mb-0">
                    Kami memiliki tim ahli yang berdedikasi untuk memberikan layanan terbaik dalam penerbitan buku dan
                    jurnal. Setiap anggota tim kami memiliki keahlian khusus yang mendukung visi dan misi RITECS.
                </p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="team-item">
                        <div class="team-img">
                            <img src="assets/img/team-1.jpg" class="img-fluid rounded-top w-100" alt="">
                            <div class="team-icon">
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-0" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="team-title p-4">
                            <h4 class="mb-0">David James</h4>
                            <p class="mb-0">Profession</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="team-item">
                        <div class="team-img">
                            <img src="assets/img/team-2.jpg" class="img-fluid rounded-top w-100" alt="">
                            <div class="team-icon">
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-0" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="team-title p-4">
                            <h4 class="mb-0">David James</h4>
                            <p class="mb-0">Profession</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.6s">
                    <div class="team-item">
                        <div class="team-img">
                            <img src="assets/img/team-3.jpg" class="img-fluid rounded-top w-100" alt="">
                            <div class="team-icon">
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-0" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="team-title p-4">
                            <h4 class="mb-0">David James</h4>
                            <p class="mb-0">Profession</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.8s">
                    <div class="team-item">
                        <div class="team-img">
                            <img src="assets/img/team-4.jpg" class="img-fluid rounded-top w-100" alt="">
                            <div class="team-icon">
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-2" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                                <a class="btn btn-primary btn-sm-square rounded-pill mb-0" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="team-title p-4">
                            <h4 class="mb-0">David James</h4>
                            <p class="mb-0">Profession</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Team End -->

    <!-- Testimonial Start -->
    <!-- <div class="container-fluid testimonial pb-5 mt-5">
        <div class="container pb-5">
            <div class="text-center mx-auto pb-5" style="max-width: 800px;">
                <h4 class="text-primary wow fadeInUp" data-wow-delay="0.2s">Testimonial</h4>
                <h1 class="display-5 mb-4 wow fadeInUp" data-wow-delay="0.4s">What Our Customers Are Saying</h1>
                <p class="mb-0 wow fadeInUp" data-wow-delay="0.6s">
                    Kami bangga telah membantu banyak penulis dan akademisi dalam menerbitkan karya mereka. Berikut adalah
                    beberapa testimoni dari klien kami yang puas dengan layanan RITECS.
                </p>
            </div>
            <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.2s">
                <div class="testimonial-item bg-light rounded">
                    <div class="row g-0">
                        <div class="col-4  col-lg-4 col-xl-3">
                            <div class="h-100">
                                <img src="assets/img/testimonial-1.jpg" class="img-fluid h-100 rounded"
                                    style="object-fit: cover;" alt="">
                            </div>
                        </div>
                        <div class="col-8 col-lg-8 col-xl-9">
                            <div class="d-flex flex-column my-auto text-start p-4">
                                <h4 class="text-dark mb-0">Client Name</h4>
                                <p class="mb-3">Profession</p>
                                <div class="d-flex text-primary mb-3">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="mb-0">
                                    "Pelayanan RITECS sangat profesional dan responsif. Proses penerbitan buku saya berjalan
                                    lancar, mulai dari penyuntingan hingga terbit ber-ISBN. Sangat direkomendasikan untuk
                                    penulis pemula maupun profesional!"
                                </p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item bg-light rounded">
                    <div class="row g-0">
                        <div class="col-4  col-lg-4 col-xl-3">
                            <div class="h-100">
                                <img src="assets/img/testimonial-2.jpg" class="img-fluid h-100 rounded"
                                    style="object-fit: cover;" alt="">
                            </div>
                        </div>
                        <div class="col-8 col-lg-8 col-xl-9">
                            <div class="d-flex flex-column my-auto text-start p-4">
                                <h4 class="text-dark mb-0">Client Name</h4>
                                <p class="mb-3">Profession</p>
                                <div class="d-flex text-primary mb-3">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star text-body"></i>
                                </div>
                                <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim error
                                    molestiae aut modi corrupti fugit eaque rem nulla incidunt temporibus quisquam,
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item bg-light rounded">
                    <div class="row g-0">
                        <div class="col-4  col-lg-4 col-xl-3">
                            <div class="h-100">
                                <img src="assets/img/testimonial-3.jpg" class="img-fluid h-100 rounded"
                                    style="object-fit: cover;" alt="">
                            </div>
                        </div>
                        <div class="col-8 col-lg-8 col-xl-9">
                            <div class="d-flex flex-column my-auto text-start p-4">
                                <h4 class="text-dark mb-0">Client Name</h4>
                                <p class="mb-3">Profession</p>
                                <div class="d-flex text-primary mb-3">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star text-body"></i>
                                    <i class="fas fa-star text-body"></i>
                                </div>
                                <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim error
                                    molestiae aut modi corrupti fugit eaque rem nulla incidunt temporibus quisquam,
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Testimonial End -->
     <!-- pop up start -->
      <div class="modal fade" id="ojsPopupModal" tabindex="-1" aria-labelledby="ojsPopupModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ojsPopupModalLabel">Informasi Publikasi Jurnal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>
                        Temukan riset terbaru dan publikasi ilmiah berkualitas di Open Journal System (OJS) kami. Kami berkomitmen untuk menyebarkan pengetahuan dan inovasi di bidang Computer Science.
                    </p>
                    <p class="mb-0">
                        Kunjungi sekarang untuk mengakses artikel-artikel terbaru!
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Tutup</button>
                    <a href="{{ route('journal') }}" class="btn btn-primary rounded-pill {{ in_array($title ?? '', ['Jurnal', 'Detail Jurnal']) ? 'active' : '' }}">Jurnal Kami</a>
                </div>
            </div>
        </div>
        </div>

    <!-- pop up end -->


@endsection