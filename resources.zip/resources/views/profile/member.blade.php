@extends('layouts.profile')

@section('content')

    <div class="d-flex justify-content-between w-100">
        <span class="text-dark mb-4 d-none d-md-flex">
            <img src="{{ asset('assets/img/team-1.jpg') }}" class="bg-dark rounded object-fit-cover img-profile-profile me-3" alt="">
            <div class="nama-profile">
                <h5 class="mb-0 fw-bold">Hallo, Anur Mustakim </h5>
                <span class="normal-text text-member bg-primary small">Membership Aktif</span>
            </div>
        </span>
        <span class="d-none d-md-flex flex-nowrap text-nowrap small">
            <a href="" class="normal-text">Profile/</a>
            <a href="#" class="text-dark">Membership</a>
        </span>
    </div>

    <div class="shadow-none membership-card mb-4 border-0 position-relative">
        <div class="row g-0 align-items-center py-2">
            <div class="col-xl-4 text-start position-relative membership-image-wrapper">
                <img src="{{ asset('assets/img/logo/membership.svg') }}" class="img-fluid" alt="Membership Card" style="max-height:400px;">
                <div class="membership-image-overlay d-flex flex-column justify-content-center align-items-center text-center">
                    <a href="{{ asset('assets/img/logo/membership.svg') }}" target="_blank" class="btn btn-light btn-sm rounded-pill fw-normal mb-2 px-3">
                        <i class="bi bi-eye me-1"></i> Lihat Kartu
                    </a>
                    <a href="#" target="_blank" download="{{ asset('assets/img/logo/membership.svg') }}" class="btn btn-primary btn-sm rounded-pill fw-normal px-3">
                        <i class="bi bi-download me-1"></i> Unduh Kartu
                    </a>
                </div>
            </div>
            <div class="col-xl-8 p-0 p-xl-4 pt-xl-0 pt-4 text-center text-md-start">
                <h4 class="fw-bold text-dark mb-1">Premium Membership</h4>
                <p class="mb-2 text-muted">Berlaku hingga: <strong>31 Desember 2025</strong></p>
                <a href="#" class="btn btn-sm btn-dark btn-login-me rounded-pill fw-normal px-3">
                    <i class="bi bi-clock-history me-1"></i> Perpanjang Membership
                </a>
            </div>
        </div>
    </div>

    <div class="row g-4 pt-2 pt-xl-3">
        <div class="col-xl-6">
            <div class="card action-card border border-1 h-100 shadow-none">
                <div class="card-body p-3">
                    <h6 class="fw-semibold text-dark">
                        <i class="bi bi-book-fill me-1"></i>Upload Buku
                    </h6>
                    <p class="mb-3 text-muted">
                        Layanan ini memungkinkan Anda mempublikasikan buku ke platform kami secara profesional.
                        Dapatkan ISBN resmi, desain cover, layout isi, dan distribusi digital.
                    </p>
                    <a href="#" class="btn btn-sm btn-outline-dark rounded-pill fw-normal px-3">
                        <i class="fas fa-upload me-1"></i> Upload Buku Sekarang
                    </a>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card action-card border border-1 h-100 shadow-none">
                <div class="card-body p-3">
                    <h6 class="fw-semibold text-primary">
                        <i class="fas fa-file-alt me-1"></i> Upload Jurnal
                    </h6>
                    <p class="mb-3 text-muted">
                        Submit jurnal Anda untuk dipublikasikan ke portal akademik nasional/internasional.
                        Tim kami akan membantu proses peer-review dan penerbitan.
                    </p>
                    <a href="#" class="btn btn-sm btn-outline-primary rounded-pill fw-normal px-3">
                        <i class="fas fa-upload me-1"></i> Upload Jurnal Sekarang
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="mb-4 mt-5">
        <h4 class="fw-semibold border-bottom border-primary pb-2 text-center text-md-start">Keuntungan Membership</h4>
        <div class="row g-4 mt-1">
            <div class="col-xl-4">
                <div class="card benefit-card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="benefit-icon shadow-sm mb-3">
                            <i class="bi bi-gift fs-3"></i>
                        </div>
                        <h5 class="fw-bold">Diskon Eksklusif</h5>
                        <p class="text-muted mb-0">Potongan harga khusus untuk produk dan layanan terpilih.</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card benefit-card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="benefit-icon shadow-sm mb-3">
                            <i class="bi bi-stars fs-3"></i>
                        </div>
                        <h5 class="fw-bold">Akses Premium</h5>
                        <p class="text-muted mb-0">Buka konten dan fitur eksklusif hanya untuk member.</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card benefit-card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="benefit-icon shadow-sm mb-3">
                            <i class="bi bi-headset fs-3"></i>
                        </div>
                        <h5 class="fw-bold">Prioritas Layanan</h5>
                        <p class="text-muted mb-0">Respons dan dukungan lebih cepat dari tim kami.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
