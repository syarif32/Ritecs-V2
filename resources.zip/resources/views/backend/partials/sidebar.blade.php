    <aside class="sidebar-left border-right bg-white shadow" id="leftSidebar" data-simplebar>
        <a href="#" class="btn collapseSidebar toggle-btn d-lg-none text-muted ml-2 mt-3" data-toggle="toggle">
          <i class="fe fe-x"><span class="sr-only"></span></i>
        </a>
        <nav class="navbar navbar-light w-100">
          <!-- nav bar -->
          <div class="w-100 mb-4 d-flex">
            <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="{{ route('home') }}">
              <img src="{{ asset('assets/img/logo/logo-text.webp')}}" id="logo" class="navbar-brand-img brand-lg" alt="">
            </a>
          </div>

          <ul class="navbar-nav flex-fill w-100 mb-2">
            <li class="nav-item {{ in_array($title ?? '', ['Dashboard', '']) ? 'active' : '' }} dropdown">
              <a href="#dashboard" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle nav-link">
                <i class="fe fe-home fe-16"></i>
                <span class="ml-3 item-text">Dashboard</span><span class="sr-only">(current)</span>
              </a>

              <!-- properti "show" untuk open dropdown -->
              <ul class="collapse list-unstyled pl-4 w-100 {{ in_array($title ?? '', ['Dashboard', '']) ? 'show' : '' }}" id="dashboard">
                <li class="nav-item">
                  <a class="nav-link {{ ($title ?? '') === 'Dashboard' ? 'active' : '' }} pl-3" href="{{ route('admin.dashboard')}}"><span class="ml-1 item-text">Analytics</span></a>
                </li>
              </ul>

            </li>
          </ul>

          <ul class="navbar-nav flex-fill w-100 mb-2">
            <li class="nav-item {{ in_array($title ?? '', ['Journal Data', 'Add Journal', 'Edit Journal', 'Book Data', 'Edit Book', 'Add Book']) ? 'active' : '' }} dropdown">
              <a href="#publish" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle nav-link">
                <i class="fe fe-file-text fe-16"></i>
                <span class="ml-3 item-text">Published</span>
              </a>

              <!-- properti "show" untuk open dropdown -->
              <ul class="collapse list-unstyled pl-4 w-100 {{ in_array($title ?? '', ['Journal Data', 'Add Journal', 'Edit Journal', 'Book Data', 'Edit Book', 'Add Book']) ? 'show' : '' }}" id="publish">
                <li class="nav-item"> 
                  <a class="nav-link {{ in_array($title ?? '', ['Book Data', 'Add Book', 'Edit Book']) ? 'active' : '' }} pl-3" href="{{ route('admin.published-books')}}"><span class="ml-1 item-text">Books</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link {{ in_array($title ?? '', ['Journal Data', 'Add Journal', 'Edit Journal']) ? 'active' : '' }} pl-3" href="{{ route('admin.published-journals')}}"><span class="ml-1 item-text">Journals</span></a>
                </li>
              </ul>

            </li>
          </ul>

          <ul class="navbar-nav flex-fill w-100 mb-2">
            <li class="nav-item {{ in_array($title ?? '', ['Keywords', 'Add Keywords', 'Edit Keywords', 'Categories', 'Add Category', 'Edit Category', 'Writers', 'Add Writer', 'Edit Writer']) ? 'active' : '' }} dropdown">
              <a href="#publishUtils" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle nav-link">
                <i class="fe fe-git-pull-request fe-16"></i>
                <span class="ml-3 item-text">Publish Utils</span>
              </a>

              <!-- properti "show" untuk open dropdown -->
              <ul class="collapse list-unstyled pl-4 w-100 {{ in_array($title ?? '', ['Keywords', 'Add Keywords', 'Edit Keywords', 'Categories', 'Add Category', 'Edit Category', 'Writers', 'Add Writer', 'Edit Writer']) ? 'show' : '' }}" id="publishUtils">
                <li class="nav-item"> 
                  <a class="nav-link {{ in_array($title ?? '', ['Categories', 'Add Category', 'Edit Category']) ? 'active' : '' }} pl-3" href="{{ route('admin.categories')}}"><span class="ml-1 item-text">Book Categories</span></a>
                </li>
                <li class="nav-item"> 
                  <a class="nav-link {{ in_array($title ?? '', ['Writers', 'Add Writer', 'Edit Writer']) ? 'active' : '' }} pl-3" href="{{ route('admin.writers')}}"><span class="ml-1 item-text">Book Writters</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link {{ in_array($title ?? '', ['Keywords', 'Add Keywords', 'Edit Keywords']) ? 'active' : '' }} pl-3" href="{{ route('admin.keywords')}}"><span class="ml-1 item-text">Journal keywords</span></a>
                </li>
              </ul>

            </li>
          </ul>

          <form method="POST" action="{{ route('logout') }}" class="w-100">
            @csrf
            <div class="btn-box w-100 mt-4 mb-1">
              <button type="submit" class="btn mb-2 btn-primary small btn-block w-100">
                <i class="fe fe-log-out fe-12 mx-2"></i><span class="small">Log Out</span>
              </button>
            </div>
          </form>

        </nav>
      </aside>