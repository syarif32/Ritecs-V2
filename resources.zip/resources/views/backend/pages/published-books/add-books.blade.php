@extends('backend.layouts.main')

@section('content')
<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-12">
      <h2 class="page-title">Add Book</h2>
        <div class="row">
        <div class="col-md-8">
          <div class="card shadow mb-4">
            <div class="card-body position-relative">
              @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show mt-2">
                  {{ session('success') }}
                  <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
              @endif

              @if(session('warning'))
                <div class="alert alert-warning alert-dismissible fade show mt-2">
                  {{ session('warning') }}
                  <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
              @endif
              <form action="{{ route('admin.store-books') }}" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf
                <div class="form-row">
                  <!-- Cover -->
                  <div class="form-group col-md-12">
                      <label for="coverImage" class="font-weight-bold">Book Cover</label>
                      <div class="upload-box" id="uploadBox">
                          <input type="file" id="coverImage" name="coverImage" accept="image/*" hidden>
                          <img id="previewImage" 
                              src="{{ asset('assets/published/books/book_default.png') }}"
                              alt="Preview" style="max-width: 150px;">
                      </div>
                  </div>

                  <!-- Title -->
                  <div class="form-group col-12 col-xl-6">
                      <label for="title">Title</label>
                      <input type="text" id="title" name="title" class="form-control" required>
                  </div>

                  <!-- Publisher -->
                  <div class="form-group col-12 col-xl-6">
                      <label for="publisher">Publisher</label>
                      <input type="text" id="publisher" name="publisher" class="form-control">
                  </div>

                  <!-- ISBN -->
                  <div class="form-group col-12 col-xl-6">
                      <label for="isbn">ISBN</label>
                      <input type="text" id="isbn" name="isbn" class="form-control" placeholder="978-634-04-1924-5">
                  </div>

                  <!-- Publish Date -->
                  <div class="form-group col-12 col-xl-6">
                    <label for="publish_date">Publish Date</label>
                    <div class="input-group">
                      <input type="date" class="form-control" id="publish_date" name="publish_date">
                    </div>
                  </div>

                  <!-- Pages + Dimensi -->
                  <div class="form-group col-12 col-xl-6 mb-0">
                    <div class="form-row">
                      <div class="form-group col-6">
                        <label for="pages">Pages</label>
                        <input type="number" id="pages" name="pages" class="form-control">
                      </div>
                      <div class="form-group col-6">
                        <label for="width">Width (cm)</label>
                        <input type="number" step="0.01" id="width" name="width" class="form-control">
                      </div>
                      <div class="form-group col-6">
                        <label for="length">Length (cm)</label>
                        <input type="number" step="0.01" id="length" name="length" class="form-control">
                      </div>
                      <div class="form-group col-6">
                        <label for="thickness">Thickness (cm)</label>
                        <input type="number" step="0.01" id="thickness" name="thickness" class="form-control">
                      </div>
                    </div>
                  </div>

                  <!-- Synopsis -->
                  <div class="form-group col-12 col-xl-6">
                    <label for="Synopsis">Synopsis</label>
                    <textarea class="form-control py-1" id="Synopsis" name="Synopsis" rows="5"></textarea>
                  </div>

                  <!-- Category -->
                  <div class="form-group col-12 col-xl-6">
                    <label for="category">Category</label>
                    <select class="form-control select2-multi" name="category[]" id="category" multiple required>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->category_id }}">{{ $cat->name }}</option>
                        @endforeach
                    </select>
                  </div>

                  <!-- Writer -->
                  <div class="form-group col-12 col-xl-6">

                    <label for="writter">Writer</label>
                    <div class="form-row">
                      <div class="col-10">
                        <select class="form-control select2-multi" name="writter[]" id="writter" multiple required>
                            @foreach($writers as $writer)
                                <option value="{{ $writer->writer_id }}">{{ $writer->name }}</option>
                            @endforeach
                        </select>
                      </div>
                      <div class="col-2">
                        <button class="btn btn-outline-primary small" data-toggle="modal" data-target="#addWriterModal" data-whatever="@mdo">+ Writer</button>
                      </div>
 
                    </div>

                  </div>

                  <!-- Price -->
                  <div class="form-group col-12 col-xl-6">
                    <label for="print_price">Print Price</label>
                    <input type="number" id="print_price" name="print_price" class="form-control" placeholder="50000">
                  </div>
                  <div class="form-group col-12 col-xl-6">
                    <label for="ebook_price">E Book Price</label>
                    <input type="number" id="ebook_price" name="ebook_price" class="form-control" placeholder="20000">
                  </div>

                  <!-- Ebook Path -->
                  <div class="form-group col-12">
                      <label for="ebook_path">E Book Path</label>
                      <input type="text" id="ebook_path" name="ebook_path" class="form-control" placeholder="https://ritecs.org/">
                  </div>

                  <!-- Buttons -->
                  <div class="col-12 d-flex justify-content-start mt-3">
                      <button type="submit" class="btn btn-primary mr-2">Add Book</button>
                      <a href="{{ route('admin.published-books') }}" class="btn btn-secondary">Cancel</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div> 
    </div>
  </div>
</div>



<div class="modal fade" id="addWriterModal" tabindex="-1" role="dialog" aria-labelledby="addWriterModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addWriterModalLabel">Add New Writer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="writerFormModal" action="{{ route('admin.writers.store') }}" method="POST">
          @csrf
          <div id="writer-fields-modal">
            <label>Writer Name</label>
            <div class="form-group">
              <div class="row p-0 m-0 g-2">
                <div class="col-12 col-md-5 px-0 py-1 p-md-0 pr-md-3">
                  <input type="text" class="form-control" name="names[]" required>
                </div>
                <div class="col-12 col-md-5 px-0 py-1 p-md-0 pr-md-3">
                  <select class="form-control" name="user_ids[]">
                    <option value="">-- User Relations (opsional) --</option>
                    @foreach($users as $user)
                      <option value="{{ $user->user_id }}">{{ $user->full_name }} - {{ $user->email }}</option>
                    @endforeach
                  </select>
                </div>
                <div class="col-12 col-md-2 px-0 py-2 p-md-0">
                  <button type="button" class="btn btn-outline-primary w-100" onclick="addFieldModal(event)">+1 item</button>
                </div>
              </div>
            </div>
          </div>
          <p class="text-muted">Menambahkan data <Strong>Writter</Strong> akan memuat ulang halaman</p>


          <button type="submit" class="btn btn-primary">Save</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </form>

      </div>
    </div>
  </div>
</div>

<script>
  // Fungsi untuk tambah field baru di modal
  function addFieldModal(e) {
    e.preventDefault();
    let div = document.createElement('div');
    div.classList.add('form-group');
    div.innerHTML = `
      <div class="row p-0 m-0 g-2">
        <div class="col-12 col-md-5 px-0 py-1 p-md-0 pr-md-3">
          <input type="text" class="form-control" name="names[]" required>
        </div>
        <div class="col-12 col-md-5 px-0 py-1 p-md-0 pr-md-3">
          <select class="form-control" name="user_ids[]">
            <option value="">-- User Relations (opsional) --</option>
            @foreach($users as $user)
              <option value="{{ $user->user_id }}">{{ $user->full_name }} - {{ $user->email }}</option>
            @endforeach
          </select>
        </div>
        <div class="col-12 col-md-2 px-0 py-2 p-md-0">
          <button type="button" class="btn btn-outline-danger w-100" onclick="this.closest('.form-group').remove()">Delete</button>
        </div>
      </div>
    `;
    document.getElementById('writer-fields-modal').appendChild(div);
  }
</script>

@endsection
